declare module 'sse';
