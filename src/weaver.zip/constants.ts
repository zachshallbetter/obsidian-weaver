export const WEAVER_THREAD_VIEW = 'weaver_thread_view';
